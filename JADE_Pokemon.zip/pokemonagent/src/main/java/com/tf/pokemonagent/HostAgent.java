/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.tf.pokemonagent;
import jade.core.Agent;

public class HostAgent extends Agent {
    @Override
    protected void setup() {
        System.out.println("Hello! Host-agent " + getAID().getName() + " is ready.");
        // Añadir comportamientos específicos del HostAgent si es necesario
    }

    protected void takeDown() {
        System.out.println("Host-agent " + getAID().getName() + " terminating.");
    }
}

