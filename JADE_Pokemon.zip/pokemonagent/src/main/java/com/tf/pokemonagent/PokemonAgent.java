/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */


package com.tf.pokemonagent;

import jade.core.Agent;
import java.util.Random;

public class PokemonAgent extends Agent {
    private String tipo;
    private String pokemonName;
    private boolean active = true;
    private int x, y;

    protected void setup() {
        Object[] args = getArguments();
        if (args != null && args.length > 0) {
            tipo = (String) args[0];
            pokemonName = (String) args[1];
            x = new Random().nextInt(50);
            y = new Random().nextInt(50);
            System.out.println("Hello! Pokemon-agent " + getAID().getName() + " is ready.");

            addBehaviour(new MoveBehaviour(this, 1000));
            addBehaviour(new FightBehaviour(this, 2000));
        } else {
            System.out.println("No type and name specified.");
            doDelete();
        }
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public void setPosition(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public String getTipo() {
        return tipo;
    }

    public String getPokemonName() {
        return pokemonName;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    protected void takeDown() {
        System.out.println("Pokemon-agent " + getAID().getName() + " terminating.");
    }
}




