package com.tf.pokemonagent;

import jade.core.behaviours.TickerBehaviour;
import java.util.Random;

public class MoveBehaviour extends TickerBehaviour {
    private PokemonAgent agent;
    private Random random = new Random();

    public MoveBehaviour(PokemonAgent agent, long period) {
        super(agent, period);
        this.agent = agent;
    }

    protected void onTick() {
        int x = agent.getX();
        int y = agent.getY();
        x = (x + random.nextInt(3) - 1 + 50) % 50;
        y = (y + random.nextInt(3) - 1 + 50) % 50;
        agent.setPosition(x, y);
        PokemonWorld.getInstance().updateAgentPosition(agent);
    }
}
