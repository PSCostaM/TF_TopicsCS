package com.tf.pokemonagent;

import jade.core.behaviours.TickerBehaviour;
import java.util.List;
import java.util.Random;

public class FightBehaviour extends TickerBehaviour {
    private PokemonAgent agent;
    private Random random = new Random();

    public FightBehaviour(PokemonAgent agent, long period) {
        super(agent, period);
        this.agent = agent;
    }

    protected void onTick() {
        List<PokemonAgent> nearbyAgents = PokemonWorld.getInstance().getNearbyAgents(agent);
        for (PokemonAgent opponent : nearbyAgents) {
            if (agent.isActive() && opponent.isActive() && !agent.equals(opponent)) {
                battle(opponent);
                break;
            }
        }
    }

    private void battle(PokemonAgent opponent) {
        if (typeAdvantage(agent.getTipo(), opponent.getTipo())) {
            opponent.setActive(false);
            PokemonWorld.getInstance().removeAgent(opponent);
        } else if (typeAdvantage(opponent.getTipo(), agent.getTipo())) {
            agent.setActive(false);
            PokemonWorld.getInstance().removeAgent(agent);
        } else {
            if (random.nextBoolean()) {
                opponent.setActive(false);
                PokemonWorld.getInstance().removeAgent(opponent);
            } else {
                agent.setActive(false);
                PokemonWorld.getInstance().removeAgent(agent);
            }
        }
    }

    private boolean typeAdvantage(String tipo1, String tipo2) {
        // Implementar lógica de ventaja de tipo
        return false;
    }
}
