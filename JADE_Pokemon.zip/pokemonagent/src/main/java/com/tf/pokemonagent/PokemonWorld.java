package com.tf.pokemonagent;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PokemonWorld {
    private static PokemonWorld instance = new PokemonWorld();
    private Map<PokemonAgent, Point> agentPositions = new HashMap<>();
    private JPanel panel;

    private PokemonWorld() {
        JFrame frame = new JFrame("Pokemon World");
        frame.setSize(800, 800);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        panel = new JPanel() {
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                for (Map.Entry<PokemonAgent, Point> entry : agentPositions.entrySet()) {
                    PokemonAgent agent = entry.getKey();
                    Point pos = entry.getValue();
                    g.setColor(getColorByType(agent.getTipo()));
                    g.fillOval(pos.x * 16, pos.y * 16, 16, 16);
                    g.drawString(agent.getPokemonName(), pos.x * 16, pos.y * 16);
                }
            }
        };
        frame.add(panel);
        frame.setVisible(true);
    }

    public static PokemonWorld getInstance() {
        return instance;
    }

    public void updateAgentPosition(PokemonAgent agent) {
        agentPositions.put(agent, new Point(agent.getX(), agent.getY()));
        panel.repaint();
    }

    public List<PokemonAgent> getNearbyAgents(PokemonAgent agent) {
        List<PokemonAgent> nearbyAgents = new ArrayList<>();
        Point pos = agentPositions.get(agent);
        for (Map.Entry<PokemonAgent, Point> entry : agentPositions.entrySet()) {
            if (!entry.getKey().equals(agent) && pos.distance(entry.getValue()) <= 5) {
                nearbyAgents.add(entry.getKey());
            }
        }
        return nearbyAgents;
    }

    public void removeAgent(PokemonAgent agent) {
        agentPositions.remove(agent);
        agent.doDelete();
        panel.repaint();
    }

    private Color getColorByType(String tipo) {
        switch (tipo) {
            case "agua":
                return Color.BLUE;
            case "fuego":
                return Color.RED;
            case "eléctrico":
                return Color.YELLOW;
            case "planta":
                return Color.GREEN;
            default:
                return Color.BLACK;
        }
    }
}
