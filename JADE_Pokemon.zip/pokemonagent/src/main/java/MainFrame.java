import jade.core.Profile;
import jade.core.ProfileImpl;
import jade.core.Runtime;
import jade.wrapper.AgentController;
import jade.wrapper.ContainerController;

import javax.swing.*;
import java.util.Random;

import com.tf.pokemonagent.PokemonWorld;  // Asegúrate de importar PokemonWorld

public class MainFrame {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            // Inicializa el mundo Pokémon
            PokemonWorld pokemonWorld = PokemonWorld.getInstance();

            // Configura el contenedor JADE
            Runtime rt = Runtime.instance();
            Profile p = new ProfileImpl();
            ContainerController cc = rt.createMainContainer(p);

            try {
                // Tipos de Pokémon
                String[] tipos = {"agua", "fuego", "eléctrico", "planta"};
                
                // Crea y lanza los agentes Pokémon
                for (int i = 0; i < 100; i++) {  // Ajustado a 100 agentes para mejor visualización
                    String tipo = tipos[new Random().nextInt(tipos.length)];
                    String name = "Pokemon_" + (i + 1);
                    AgentController ac = cc.createNewAgent(name, "com.tf.pokemonagent.PokemonAgent", new Object[]{tipo, name});
                    ac.start();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}
